export const environment = {
  production: true,
  clientID: "4f09f0f2e4d74ab5861c5f5fafd81cc2",
  clientSecret: "99efcb5a0aa4475aa1a6ccf87e93c332"

};
